# Integration with the submitted SE project

## Grounded in the supplied files

- Project topic: **Phishing detection in IoT**.
- Group: Krish Sharma (K057), Gauri Shinde (K059), and Deetya Shivathaya (K060).
- The supplied ZIP contains `dataset_B_05_2020.csv`, the URL/content/external feature extraction scripts and a brand indicator list.
- The notebook loads the same CSV, selects numeric features, trains a CNN–LSTM, then compares baseline predictions with a simulated threat-intelligence false-positive override.
- The submitted notebook outputs report a baseline accuracy of 0.934092 and an “improved” accuracy of 0.952173 for that notebook experiment.
- No saved CNN–LSTM weights or fully connected production threat-intelligence integration were present in the uploaded files.

## What this web build changes for deployment

- Ships a saved CNN–LSTM trained on the 52 URL-derived features extracted from the dataset's URLs.
- Extracts URL features from the supplied URL string without visiting it.
- Returns a model score with conservative explanatory language, local findings and a scan record.
- Stores history locally via SQLite and offers bulk scan and CSV export.
- Explicitly marks external reputation intelligence as not connected. A real provider should be integrated through an adapter with API-key configuration, caching, rate limiting, timeouts and privacy disclosure; a TLD or hand-written trust list must not be represented as a real reputation check.

## Proposed architecture

```text
Browser / installable PWA
        | JSON over same-origin HTTP
        v
FastAPI routes
  | scan request
  v
URL normalization + URL feature extractor
        |
        v
Saved CNN–LSTM model + fitted StandardScaler -> score + human-readable URL findings
        |
        +----> SQLite scan history / stats / CSV export
```

## Current boundaries

This is URL-level screening, not packet inspection or active IoT-device blocking. A later version could add a safe URL reputation provider and a separate IoT telemetry collector, but those require additional infrastructure and explicit security/privacy design.
