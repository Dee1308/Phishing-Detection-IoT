"""Train the project's CNN-LSTM architecture on the URL-derived features the web scanner can compute.

The notebook model uses all 87 dataset columns, but 35 of them (domain age, page rank, hyperlink ratios, ...)
cannot be read from a URL string. Feeding those as zeros made every site look like phishing, so the deployed
model is trained only on features extracted from the URL itself, using the same extractor used at scan time."""
from __future__ import annotations
import json, random
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, roc_auc_score
import joblib
from app.features import FEATURE_COLUMNS, extract_url_features
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'/'dataset_B_05_2020.csv'; ART=ROOT/'artifacts'; ART.mkdir(exist_ok=True)
SEED=42
random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
torch.set_num_threads(1)
class CNNLSTM(nn.Module):
    def __init__(self, n_features):
        super().__init__()
        self.conv1=nn.Conv1d(1,32,kernel_size=3,padding=1)
        self.conv2=nn.Conv1d(32,64,kernel_size=3,padding=1)
        self.pool=nn.MaxPool1d(2); self.drop1=nn.Dropout(.25)
        self.lstm=nn.LSTM(input_size=64,hidden_size=128,batch_first=True)
        self.drop2=nn.Dropout(.5); self.out=nn.Linear(128,1)
    def forward(self,x):
        x=torch.relu(self.conv1(x)); x=torch.relu(self.conv2(x)); x=self.pool(x); x=self.drop1(x)
        x=x.transpose(1,2); _,(h,_)=self.lstm(x)
        return self.out(self.drop2(h[-1])).squeeze(1)

def main():
    df=pd.read_csv(DATA); target='status' if 'status' in df else df.columns[-1]
    cols=list(FEATURE_COLUMNS); rows=[]; keep=[]
    for i,u in enumerate(df['url']):
        try: rows.append([extract_url_features(u)[1].get(c,0.0) for c in cols]); keep.append(i)
        except ValueError: pass
    X=np.nan_to_num(np.array(rows,dtype=np.float32))
    y=(df[target].astype(str).str.lower().eq('phishing')).to_numpy(dtype=np.float32)[keep]
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.30,random_state=SEED,stratify=y)
    scaler=StandardScaler(); Xtr=scaler.fit_transform(Xtr).astype('float32'); Xte=scaler.transform(Xte).astype('float32')
    # Original notebook architecture: Conv1D(32) -> Conv1D(64) -> MaxPool -> Dropout -> LSTM(128) -> Dropout -> sigmoid.
    model=CNNLSTM(X.shape[1]); opt=torch.optim.Adam(model.parameters(),lr=.001); loss_fn=nn.BCEWithLogitsLoss()
    xt=torch.tensor(Xtr).unsqueeze(1); yt=torch.tensor(ytr); xv=torch.tensor(Xte).unsqueeze(1)
    rng=np.random.default_rng(SEED); batch=256
    EPOCHS=40
    for epoch in range(EPOCHS):
        model.train(); order=rng.permutation(len(xt)); running=0
        for start in range(0,len(order),batch):
            ix=order[start:start+batch]; opt.zero_grad(); loss=loss_fn(model(xt[ix]),yt[ix]); loss.backward(); opt.step(); running+=loss.item()*len(ix)
        print(f'Epoch {epoch+1}/{EPOCHS} - loss {running/len(xt):.4f}',flush=True)
    model.eval()
    with torch.no_grad(): probs=torch.sigmoid(model(xv)).numpy()
    pred=(probs>=.5).astype(int); cm=confusion_matrix(yte,pred).tolist()
    metrics={'model_name':'CNN-LSTM (URL-feature model)','dataset':'dataset_B_05_2020.csv (URL-derived features only)','split':'70% training / 30% hold-out test, stratified, random_state=42','excluded_features':'35 content/network columns that cannot be derived from a URL','samples_total':int(len(y)),'samples_train':int(len(ytr)),'samples_test':int(len(yte)),'feature_count':len(cols),'features':cols,'accuracy':float(accuracy_score(yte,pred)),'precision':float(precision_score(yte,pred,zero_division=0)),'recall':float(recall_score(yte,pred,zero_division=0)),'f1':float(f1_score(yte,pred,zero_division=0)),'roc_auc':float(roc_auc_score(yte,probs)),'confusion_matrix':{'true_negative':cm[0][0],'false_positive':cm[0][1],'false_negative':cm[1][0],'true_positive':cm[1][1]},'architecture':'Conv1D(32) → Conv1D(64) → MaxPooling1D(2) → Dropout(0.25) → LSTM(128) → Dropout(0.5) → Dense(1, sigmoid)','limitations':['Hold-out benchmark metrics are not a guarantee of real-world performance.','This model sees only the URL string. Page content, DNS, WHOIS and reputation signals are not used, so it is a triage signal, not a verdict.','Threat-intelligence checks are not live. The original notebook’s simulated false-positive override is not represented as a real API.']}
    torch.save({'state_dict':model.state_dict(),'n_features':len(cols),'features':cols},ART/'cnn_lstm_model.pt')
    joblib.dump({'scaler':scaler,'features':cols},ART/'preprocessing.joblib')
    (ART/'model_metrics.json').write_text(json.dumps(metrics,indent=2))
    print(json.dumps({k:metrics[k] for k in ['accuracy','precision','recall','f1','roc_auc','feature_count']},indent=2))
if __name__=='__main__': main()
