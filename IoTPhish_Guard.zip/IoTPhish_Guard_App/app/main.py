"""FastAPI backend for IoTPhish Guard."""
from __future__ import annotations

import csv
from contextlib import contextmanager
import io
import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from app.features import FEATURE_COLUMNS, _registered_parts, extract_url_features, explain_url_features

ROOT = Path(__file__).resolve().parents[1]
STATIC_DIR = ROOT / "static"
NOTEBOOK_PATH = ROOT / "artifacts" / "notebook_results.json"
METRICS_PATH = ROOT / "artifacts" / "model_metrics.json"
DB_PATH = Path(os.getenv("IOTPHISH_DB_PATH", str(ROOT / "data" / "scan_history.sqlite3")))

app = FastAPI(
    title="IoTPhish Guard API",
    version="1.0.0",
    description="Local URL-pattern screening API for the Phishing Detection in IoT student project.",
)
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

try:
    from app.model import CNNLSTMPredictor
    MODEL = CNNLSTMPredictor()
    MODEL_FEATURES = list(MODEL.features)
except Exception as exc:  # fail clearly on startup rather than silently use rules only
    MODEL = None
    MODEL_FEATURES = FEATURE_COLUMNS
    _MODEL_LOAD_ERROR = str(exc)
else:
    _MODEL_LOAD_ERROR = ""

try:
    MODEL_METRICS = json.loads(METRICS_PATH.read_text(encoding="utf-8"))
except Exception:
    MODEL_METRICS = {
        "model_name": "CNN–LSTM — URL feature model",
        "accuracy": None,
        "precision": None,
        "recall": None,
        "f1": None,
        "roc_auc": None,
        "samples_total": None,
        "samples_test": None,
        "feature_count": len(FEATURE_COLUMNS),
    }


try:
    NOTEBOOK = json.loads(NOTEBOOK_PATH.read_text(encoding="utf-8"))
except Exception:
    NOTEBOOK = None


@contextmanager
def _connect():
    """Open a short-lived SQLite connection and always close it after the operation."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(str(DB_PATH), timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA busy_timeout = 10000")
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def _init_db() -> None:
    with _connect() as con:
        con.execute(
            """CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                original_url TEXT NOT NULL,
                normalized_url TEXT NOT NULL,
                hostname TEXT NOT NULL,
                registered_domain TEXT NOT NULL,
                probability REAL NOT NULL,
                verdict TEXT NOT NULL,
                risk_tier TEXT NOT NULL,
                findings_json TEXT NOT NULL,
                features_json TEXT NOT NULL
            )"""
        )
        con.execute("CREATE INDEX IF NOT EXISTS idx_scans_created_at ON scans(created_at DESC)")


_init_db()


class ScanRequest(BaseModel):
    url: str = Field(min_length=1, max_length=2048)


class BatchScanRequest(BaseModel):
    urls: list[str] = Field(min_length=1, max_length=30)


class ScanServiceError(Exception):
    pass


def _risk_tier(probability: float) -> str:
    if probability >= 0.70:
        return "High"
    if probability >= 0.40:
        return "Moderate"
    return "Lower"


def _predict(original_url: str) -> dict[str, Any]:
    if MODEL is None:
        raise ScanServiceError(f"The model could not be loaded: {_MODEL_LOAD_ERROR or 'unknown error'}")
    normalized_url, features = extract_url_features(original_url)
    row = pd.DataFrame([[features.get(name, float("nan")) for name in MODEL_FEATURES]], columns=MODEL_FEATURES)
    probability = float(MODEL.predict_proba(row)[0][1])
    probability = min(1.0, max(0.0, probability))
    tier = _risk_tier(probability)
    verdict = "Phishing-like pattern" if probability >= 0.5 else "No strong phishing pattern"
    hostname = (urlsplit(normalized_url).hostname or "").lower()
    registered, _subdomain, _tld = _registered_parts(hostname)
    domain_for_display = registered
    # Use full hostname for single-label hosts and IPs; do not claim to identify public-suffix ownership.
    if not domain_for_display or hostname.replace(".", "").isdigit():
        domain_for_display = hostname
    findings = explain_url_features(normalized_url, features)
    return {
        "original_url": normalized_url,
        "url": normalized_url,
        "hostname": hostname,
        "registered_domain": domain_for_display,
        "probability": round(probability, 4),
        "score_percent": int(round(probability * 100)),
        "verdict": verdict,
        "risk_tier": tier,
        "findings": findings,
        "feature_count": len(features),
        "analysis_mode": "URL syntax only — no network request made",
    }


def _save_scan(result: dict[str, Any]) -> dict[str, Any]:
    created = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with _connect() as con:
        cur = con.execute(
            """INSERT INTO scans (
                created_at, original_url, normalized_url, hostname, registered_domain,
                probability, verdict, risk_tier, findings_json, features_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                created, result["original_url"], result["url"], result["hostname"],
                result["registered_domain"], result["probability"], result["verdict"],
                result["risk_tier"], json.dumps(result["findings"]), json.dumps({"count": result["feature_count"]}),
            ),
        )
        scan_id = int(cur.lastrowid)
    stored = dict(result)
    stored["id"] = scan_id
    stored["created_at"] = created
    return stored


def _scan_one(url: str) -> dict[str, Any]:
    try:
        return _save_scan(_predict(url))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except ScanServiceError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get("/", include_in_schema=False)
def home() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {
        "status": "ok" if MODEL is not None else "degraded",
        "service": "IoTPhish Guard",
        "model_loaded": MODEL is not None,
        "model_version": "1.0.0",
        "storage": "SQLite local history",
        "network_fetches_enabled": False,
        "detail": _MODEL_LOAD_ERROR if MODEL is None else "Local URL classifier is ready.",
    }


@app.get("/api/model-info")
def model_info() -> dict[str, Any]:
    return {
        "available": MODEL is not None,
        "model_name": MODEL_METRICS.get("model_name", "Local URL classifier"),
        "dataset": MODEL_METRICS.get("dataset", "Provided phishing URL dataset"),
        "split": MODEL_METRICS.get("split", "Hold-out test split"),
        "samples_total": MODEL_METRICS.get("samples_total"),
        "samples_train": MODEL_METRICS.get("samples_train"),
        "samples_test": MODEL_METRICS.get("samples_test"),
        "feature_count": len(MODEL_FEATURES),
        "accuracy": MODEL_METRICS.get("accuracy"),
        "precision": MODEL_METRICS.get("precision"),
        "recall": MODEL_METRICS.get("recall"),
        "f1": MODEL_METRICS.get("f1"),
        "roc_auc": MODEL_METRICS.get("roc_auc"),
        "confusion_matrix": MODEL_METRICS.get("confusion_matrix", {}),
        "limitations": MODEL_METRICS.get("limitations", []),
        "feature_groups": [
            "URL structure and character counts", "Hostname and domain-shape indicators",
            "Path-word patterns", "Local indicator-list matches",
        ],
        "threat_intel": "No external threat-intelligence provider is connected in this build.",
    }


@app.get("/api/benchmark")
def benchmark() -> dict[str, Any]:
    if NOTEBOOK is None:
        raise HTTPException(status_code=404, detail="artifacts/notebook_results.json is missing.")
    return NOTEBOOK


@app.get("/api/stats")
def stats() -> dict[str, Any]:
    today = datetime.now(timezone.utc).date().isoformat()
    with _connect() as con:
        total = con.execute("SELECT COUNT(*) FROM scans").fetchone()[0]
        today_count = con.execute("SELECT COUNT(*) FROM scans WHERE substr(created_at,1,10)=?", (today,)).fetchone()[0]
        high_count = con.execute("SELECT COUNT(*) FROM scans WHERE risk_tier='High'").fetchone()[0]
        # Timestamps are ISO-8601 strings, so compute the rolling window after reading recent rows.
        tiers = {r[0]: r[1] for r in con.execute("SELECT risk_tier, COUNT(*) FROM scans GROUP BY risk_tier")}
        days = {r[0]: r[1] for r in con.execute("SELECT substr(created_at,1,10), COUNT(*) FROM scans GROUP BY 1 ORDER BY 1 DESC LIMIT 14")}
        recent_rows = con.execute("SELECT created_at FROM scans ORDER BY created_at DESC LIMIT 5000").fetchall()
    cutoff = datetime.now(timezone.utc).timestamp() - 86400
    recent_count = 0
    for row in recent_rows:
        try:
            if datetime.fromisoformat(row["created_at"]).timestamp() >= cutoff:
                recent_count += 1
            else:
                break
        except (ValueError, TypeError):
            continue
    from datetime import timedelta
    base = datetime.now(timezone.utc).date()
    daily = [{"day": (base - timedelta(days=i)).isoformat(), "count": int(days.get((base - timedelta(days=i)).isoformat(), 0))} for i in range(6, -1, -1)]
    return {
        "risk_counts": {k: int(tiers.get(k, 0)) for k in ("High", "Moderate", "Lower")},
        "daily": daily,
        "total_scans": int(total),
        "scans_today_utc": int(today_count),
        "high_risk_total": int(high_count),
        "scans_last_24h": int(recent_count),
        "model_accuracy": MODEL_METRICS.get("accuracy"),
        "model_ready": MODEL is not None,
    }


def _row_to_history(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "id": row["id"],
        "created_at": row["created_at"],
        "original_url": row["original_url"],
        "url": row["normalized_url"],
        "hostname": row["hostname"],
        "registered_domain": row["registered_domain"],
        "probability": row["probability"],
        "score_percent": int(round(row["probability"] * 100)),
        "verdict": row["verdict"],
        "risk_tier": row["risk_tier"],
        "findings": json.loads(row["findings_json"]),
    }


@app.get("/api/history")
def history(limit: int = Query(default=50, ge=1, le=200), q: str = Query(default="", max_length=300)) -> dict[str, Any]:
    q = q.strip()
    with _connect() as con:
        if q:
            rows = con.execute(
                "SELECT * FROM scans WHERE normalized_url LIKE ? OR hostname LIKE ? ORDER BY id DESC LIMIT ?",
                (f"%{q}%", f"%{q}%", limit),
            ).fetchall()
        else:
            rows = con.execute("SELECT * FROM scans ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return {"items": [_row_to_history(row) for row in rows], "count": len(rows)}


@app.post("/api/scan")
def scan(request: ScanRequest) -> dict[str, Any]:
    return {"result": _scan_one(request.url)}


@app.post("/api/scan/batch")
def scan_batch(request: BatchScanRequest) -> dict[str, Any]:
    results = []
    errors = []
    for raw in request.urls:
        if not raw.strip():
            continue
        try:
            results.append(_save_scan(_predict(raw)))
        except ValueError as exc:
            errors.append({"url": raw[:2048], "error": str(exc)})
        except ScanServiceError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
    if not results and errors:
        raise HTTPException(status_code=422, detail=errors[0]["error"])
    return {"results": results, "errors": errors, "count": len(results)}


@app.get("/api/history/export")
def export_history() -> StreamingResponse:
    with _connect() as con:
        rows = con.execute("SELECT * FROM scans ORDER BY id DESC").fetchall()
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(["id", "created_at_utc", "url", "hostname", "score_percent", "verdict", "risk_tier"])
    for row in rows:
        writer.writerow([row["id"], row["created_at"], row["normalized_url"], row["hostname"], round(row["probability"] * 100), row["verdict"], row["risk_tier"]])
    out.seek(0)
    headers = {"Content-Disposition": 'attachment; filename="iotphish-scan-history.csv"'}
    return StreamingResponse(iter([out.getvalue()]), media_type="text/csv; charset=utf-8", headers=headers)


@app.delete("/api/history")
def clear_history() -> dict[str, Any]:
    with _connect() as con:
        deleted = con.execute("DELETE FROM scans").rowcount
    return {"deleted": int(deleted), "ok": True}
