(() => {
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const state = { view: 'overview', busy: false, allHistory: [], deferredInstall: null };
  const views = { overview: $('#overviewView'), history: $('#historyView'), model: $('#modelView') };

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  }
  function formatPercent(value) { return value == null || Number.isNaN(Number(value)) ? '—' : `${(Number(value) * 100).toFixed(2)}%`; }
  function formatNumber(value) { return value == null || Number.isNaN(Number(value)) ? '—' : Number(value).toLocaleString(); }
  function formatTime(iso) {
    if (!iso) return '—';
    const date = new Date(iso);
    if (Number.isNaN(date.getTime())) return '—';
    return date.toLocaleString([], {month:'short', day:'2-digit', hour:'2-digit', minute:'2-digit'});
  }
  function formatDate(value = new Date()) { return value.toLocaleDateString([], {weekday:'short', month:'short', day:'2-digit'}).toUpperCase(); }
  function verdictClass(verdict) { return String(verdict).toLowerCase().includes('phishing-like') ? 'verdict-phishing' : 'verdict-clean'; }
  function riskClass(tier) { return ({High:'risk-high', Moderate:'risk-moderate', Lower:'risk-lower'})[tier] || 'risk-lower'; }
  function scoreTrack(score, tier) { const cls = tier === 'High' ? 'score-high' : tier === 'Moderate' ? 'score-moderate' : ''; return `<div class="score-cell"><div class="score-number"><span>${escapeHtml(score)}%</span><span>${escapeHtml(tier || '')}</span></div><div class="score-track"><span class="${cls}" style="width:${Math.max(0, Math.min(100, Number(score) || 0))}%"></span></div></div>`; }

  async function api(path, options = {}) {
    const response = await fetch(path, {headers:{'Content-Type':'application/json', ...(options.headers || {})}, ...options});
    const contentType = response.headers.get('content-type') || '';
    const payload = contentType.includes('application/json') ? await response.json() : await response.text();
    if (!response.ok) {
      const detail = payload && typeof payload === 'object' ? (payload.detail || payload.message || JSON.stringify(payload)) : payload;
      throw new Error(typeof detail === 'string' ? detail : JSON.stringify(detail));
    }
    return payload;
  }
  function toast(title, message, kind = 'success') {
    const node = document.createElement('div');
    node.className = `toast ${kind === 'error' ? 'error' : ''}`;
    node.innerHTML = `<span class="toast-icon">${kind === 'error' ? '!' : '✓'}</span><div><strong>${escapeHtml(title)}</strong><p>${escapeHtml(message)}</p></div>`;
    $('#toastStack').append(node);
    window.setTimeout(() => { node.style.opacity = '0'; node.style.transform = 'translateY(5px)'; window.setTimeout(() => node.remove(), 220); }, 4200);
  }
  function setBusy(form, busy, button) {
    state.busy = busy;
    button.disabled = busy;
    button.classList.toggle('loading', busy);
    $('.button-spinner', button).hidden = !busy;
    $('.submit-icon', button).hidden = busy;
    const label = $('span:not(.button-spinner)', button);
    if (label && !label.classList.contains('button-spinner')) {
      if (!label.dataset.original) label.dataset.original = label.textContent;
      label.textContent = busy ? 'Analyzing…' : label.dataset.original;
    }
  }
  function setError(id, message) {
    const element = $(id);
    if (!element) return;
    element.textContent = message || '';
    element.hidden = !message;
  }
  function navigate(view, focus) {
    if (!views[view]) view = 'overview';
    state.view = view;
    Object.entries(views).forEach(([key, node]) => {
      node.classList.toggle('active', key === view);
      node.hidden = key !== view;
    });
    $$('.nav-link').forEach((button) => button.classList.toggle('active', button.dataset.view === view && (button.dataset.focus ? focus === button.dataset.focus : !focus)));
    const pageNames = {overview:'Overview', history:'Scan history', model:'Model & method'};
    $('#pageCrumb').textContent = pageNames[view] || 'Overview';
    $('#sidebar').classList.remove('open'); $('#mobileOverlay').classList.remove('active');
    if (view === 'history') loadHistory();
    if (view === 'model') loadModelInfo();
    if (view === 'overview' && focus === 'scanner') setTimeout(() => $('#urlInput').focus({preventScroll:true}), 40);
    window.scrollTo({top:0, behavior:'smooth'});
  }
  $$('.nav-link').forEach((button) => button.addEventListener('click', () => navigate(button.dataset.view, button.dataset.focus)));
  $$('[data-open-view]').forEach((button) => button.addEventListener('click', () => navigate(button.dataset.openView)));
  
  $('#aboutShortcut').addEventListener('click', () => navigate('model'));
  $('#mobileMenu').addEventListener('click', () => { $('#sidebar').classList.toggle('open'); $('#mobileOverlay').classList.toggle('active'); });
  $('#mobileOverlay').addEventListener('click', () => { $('#sidebar').classList.remove('open'); $('#mobileOverlay').classList.remove('active'); });

  function setMode(mode) {
    const single = mode === 'single';
    $('#singleForm').hidden = !single; $('#bulkForm').hidden = single;
    $('#singleModeTab').classList.toggle('active', single); $('#bulkModeTab').classList.toggle('active', !single);
    $('#singleModeTab').setAttribute('aria-selected', String(single)); $('#bulkModeTab').setAttribute('aria-selected', String(!single));
    $('#resultPanel').hidden = true; $('#bulkResults').hidden = true;
    setError('#singleError', ''); setError('#bulkError', '');
  }
  $('#singleModeTab').addEventListener('click', () => setMode('single'));
  $('#bulkModeTab').addEventListener('click', () => setMode('bulk'));
  $('#urlInput').addEventListener('input', () => {
    $('#urlCharCount').textContent = `${$('#urlInput').value.length.toLocaleString()} / 2,048`;
    $('#clearUrl').classList.toggle('visible', !!$('#urlInput').value);
  });
  $('#clearUrl').addEventListener('click', () => { $('#urlInput').value = ''; $('#urlInput').dispatchEvent(new Event('input')); $('#urlInput').focus(); });
  $$('.example-chip').forEach((chip) => chip.addEventListener('click', () => { $('#urlInput').value = chip.dataset.example; $('#urlInput').dispatchEvent(new Event('input')); $('#urlInput').focus(); }));
  $('#bulkInput').addEventListener('input', () => {
    const values = $('#bulkInput').value.split(/\r?\n/).map(x => x.trim()).filter(Boolean);
    $('#bulkCount').textContent = `${values.length} / 30 URLs`;
    $('#bulkCount').style.color = values.length > 30 ? '#c75454' : '';
  });

  function renderResult(result) {
    const bad = String(result.verdict).toLowerCase().includes('phishing-like');
    const tone = result.risk_tier === 'High' ? 'high' : result.risk_tier === 'Moderate' ? 'medium' : 'low';
    const findings = (result.findings || []).map((finding) => `<div class="finding-row"><span class="finding-marker ${escapeHtml(finding.level)}">${finding.level === 'high' ? '!' : finding.level === 'medium' ? '•' : 'i'}</span><div><strong>${escapeHtml(finding.title)}</strong><p>${escapeHtml(finding.detail)}</p></div></div>`).join('');
    $('#resultPanel').innerHTML = `<div class="result-header"><div><div class="result-kicker">ANALYSIS COMPLETE <span>·</span> #${escapeHtml(result.id ?? 'NEW')}</div><h3>${bad ? 'Phishing-like pattern detected' : 'No strong phishing pattern detected'}</h3><p>${bad ? 'Treat this URL carefully and verify the destination through a trusted route.' : 'The URL has fewer phishing-like patterns in the local model. This does not certify the site as safe.'}</p></div>${gauge(result.score_percent,tone)}</div><div class="result-url"><span class="result-url-icon"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3.5 12h17M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/></svg></span><div><strong>${escapeHtml(result.registered_domain || result.hostname)}</strong><small title="${escapeHtml(result.url)}">${escapeHtml(result.url)}</small></div><span class="risk-pill ${riskClass(result.risk_tier)}">${escapeHtml(result.risk_tier)} RISK</span></div><div class="result-bar-wrap"><div class="result-bar-label"><span>Phishing-pattern score</span><strong>${escapeHtml(result.score_percent)} / 100</strong></div><div class="result-bar ${tone}"><span style="width:${Math.max(0,Math.min(100,Number(result.score_percent)||0))}%"></span></div></div><div class="finding-heading"><span>OBSERVED URL SIGNALS</span><span>${(result.findings || []).length} NOTES</span></div><div class="finding-list">${findings}</div><div class="result-disclaimer"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 11v5m0-8h.01"/></svg><span>${escapeHtml(result.analysis_mode)}. A score is a screening signal, not proof of maliciousness or safety.</span></div><div class="result-actions"><button type="button" class="button button-outline button-small" id="copyScannedUrl"><svg viewBox="0 0 24 24"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/></svg> Copy URL</button><button type="button" class="button button-outline button-small" id="scanAnother"><svg viewBox="0 0 24 24"><path d="M4 7v5h5M20 17v-5h-5"/><path d="M6 17a7 7 0 0 0 11.5 1.5L20 17M4 7l2.5-1.5A7 7 0 0 1 18 7"/></svg> Scan another</button><button type="button" class="button button-primary button-small" id="viewResultHistory">Open history <svg viewBox="0 0 24 24"><path d="M5 12h14m-6-6 6 6-6 6"/></svg></button></div>`;
    $('#resultPanel').hidden = false; $('#bulkResults').hidden = true;
    $('#copyScannedUrl').addEventListener('click', async () => { try { await navigator.clipboard.writeText(result.url); toast('URL copied', 'The normalized URL was copied to your clipboard.'); } catch { toast('Copy unavailable', 'Select and copy the URL from the result.', 'error'); } });
    $('#scanAnother').addEventListener('click', () => { $('#urlInput').value = ''; $('#urlInput').dispatchEvent(new Event('input')); $('#urlInput').focus(); $('#resultPanel').hidden = true; });
    $('#viewResultHistory').addEventListener('click', () => navigate('history'));
    $('#resultPanel').scrollIntoView({behavior:'smooth',block:'nearest'});
  }
  function renderBulkResults(payload) {
    const rows = (payload.results || []).map((item) => `<tr><td><div class="url-cell"><strong title="${escapeHtml(item.url)}">${escapeHtml(item.url)}</strong><small>${escapeHtml(item.hostname)}</small></div></td><td><span class="verdict-pill ${verdictClass(item.verdict)}">${escapeHtml(item.verdict)}</span></td><td>${scoreTrack(item.score_percent,item.risk_tier)}</td><td><span class="risk-pill ${riskClass(item.risk_tier)}">${escapeHtml(item.risk_tier)}</span></td></tr>`).join('');
    const errorRows = (payload.errors || []).map((item) => `<div class="bulk-error-row"><strong>${escapeHtml(item.url)}</strong><span>${escapeHtml(item.error)}</span></div>`).join('');
    $('#bulkResults').innerHTML = `<div class="bulk-result-head"><div><div class="section-kicker"><span class="mini-square"></span> BATCH FINISHED</div><h3>${payload.count} URL${payload.count === 1 ? '' : 's'} analyzed</h3><p>Each URL was scored independently and saved to local history.</p></div><button class="button button-outline button-small" type="button" id="bulkHistoryButton">View history</button></div><div class="table-wrap"><table class="data-table"><thead><tr><th>URL / HOST</th><th>RESULT</th><th>RISK SCORE</th><th>LEVEL</th></tr></thead><tbody>${rows || '<tr><td colspan="4" class="empty-table">No valid URLs were analyzed.</td></tr>'}</tbody></table></div>${errorRows ? `<div class="bulk-errors"><strong>${payload.errors.length} URL${payload.errors.length===1?'':'s'} skipped</strong>${errorRows}</div>` : ''}`;
    $('#bulkResults').hidden = false; $('#resultPanel').hidden = true;
    $('#bulkHistoryButton').addEventListener('click', () => navigate('history'));
  }
  $('#singleForm').addEventListener('submit', async (event) => {
    event.preventDefault(); if (state.busy) return;
    setError('#singleError', ''); $('#resultPanel').hidden = true;
    const button = $('#scanButton'); setBusy($('#singleForm'), true, button);
    try { const response = await api('/api/scan', {method:'POST', body:JSON.stringify({url:$('#urlInput').value})}); renderResult(response.result); toast('Analysis complete', 'The URL scan was saved to local history.'); await loadStats(); await loadRecent(); }
    catch (error) { setError('#singleError', error.message || 'Could not analyze that URL.'); toast('Scan not completed', error.message || 'Please review the URL and try again.', 'error'); }
    finally { setBusy($('#singleForm'), false, button); }
  });
  $('#bulkForm').addEventListener('submit', async (event) => {
    event.preventDefault(); if (state.busy) return;
    setError('#bulkError', ''); $('#bulkResults').hidden = true;
    const urls = $('#bulkInput').value.split(/\r?\n/).map(x => x.trim()).filter(Boolean);
    if (!urls.length) { setError('#bulkError', 'Add at least one URL, with one URL on each line.'); return; }
    if (urls.length > 30) { setError('#bulkError', 'Bulk scans are limited to 30 URLs per batch.'); return; }
    const button = $('#bulkButton'); setBusy($('#bulkForm'), true, button);
    try { const payload = await api('/api/scan/batch', {method:'POST',body:JSON.stringify({urls})}); renderBulkResults(payload); toast('Batch complete', `${payload.count} URL${payload.count===1?'':'s'} analyzed.`); await loadStats(); await loadRecent(); }
    catch (error) { setError('#bulkError', error.message || 'Could not complete the batch.'); toast('Batch not completed', error.message || 'Review the inputs and try again.', 'error'); }
    finally { setBusy($('#bulkForm'), false, button); }
  });

  function rowHtml(item, wide = false) {
    const detail = `<div class="url-cell"><strong title="${escapeHtml(item.url)}">${escapeHtml(item.url)}</strong><small>${escapeHtml(item.hostname || '')}</small></div>`;
    const base = `<td>${detail}</td><td><span class="verdict-pill ${verdictClass(item.verdict)}">${escapeHtml(item.verdict)}</span></td><td>${scoreTrack(item.score_percent,item.risk_tier)}</td>`;
    if (wide) return `<tr><td>${detail}</td><td><span class="verdict-pill ${verdictClass(item.verdict)}">${escapeHtml(item.verdict)}</span></td><td>${scoreTrack(item.score_percent,item.risk_tier)}</td><td><span class="risk-pill ${riskClass(item.risk_tier)}">${escapeHtml(item.risk_tier)}</span></td><td>${escapeHtml(formatTime(item.created_at))}</td><td><button type="button" class="table-action" data-rescan="${escapeHtml(item.url)}" aria-label="Scan again"><svg viewBox="0 0 24 24"><path d="M4 7v5h5M20 17v-5h-5"/><path d="M6 17a7 7 0 0 0 11.5 1.5L20 17M4 7l2.5-1.5A7 7 0 0 1 18 7"/></svg></button></td></tr>`;
    return `<tr>${base}<td>${escapeHtml(formatTime(item.created_at))}</td><td><button type="button" class="table-action" data-rescan="${escapeHtml(item.url)}" aria-label="Scan again"><svg viewBox="0 0 24 24"><path d="M4 7v5h5M20 17v-5h-5"/><path d="M6 17a7 7 0 0 0 11.5 1.5L20 17M4 7l2.5-1.5A7 7 0 0 1 18 7"/></svg></button></td></tr>`;
  }
  function bindRescan() {
    $$('[data-rescan]').forEach((button) => button.addEventListener('click', () => {
      const url = button.getAttribute('data-rescan'); navigate('overview','scanner'); $('#urlInput').value = url; $('#urlInput').dispatchEvent(new Event('input')); $('#urlInput').focus();
    }));
  }
  async function loadRecent() {
    try {
      const payload = await api('/api/history?limit=5');
      $('#recentTableBody').innerHTML = payload.items.length ? payload.items.map(item => `<tr><td><div class="url-cell"><strong title="${escapeHtml(item.url)}">${escapeHtml(item.url)}</strong><small>${escapeHtml(item.hostname)}</small></div></td><td><span class="verdict-pill ${verdictClass(item.verdict)}">${escapeHtml(item.verdict)}</span></td><td>${scoreTrack(item.score_percent,item.risk_tier)}</td><td>${escapeHtml(formatTime(item.created_at))}</td><td><button type="button" class="table-action" data-rescan="${escapeHtml(item.url)}" aria-label="Scan again"><svg viewBox="0 0 24 24"><path d="M4 7v5h5M20 17v-5h-5"/><path d="M6 17a7 7 0 0 0 11.5 1.5L20 17M4 7l2.5-1.5A7 7 0 0 1 18 7"/></svg></button></td></tr>`).join('') : '<tr><td colspan="5" class="empty-table">No scans yet. Analyze a URL above to create your first record.</td></tr>';
      bindRescan();
    } catch { $('#recentTableBody').innerHTML = '<tr><td colspan="5" class="empty-table">Local history is temporarily unavailable.</td></tr>'; }
  }
  async function loadHistory() {
    try {
      const q = $('#historySearch').value.trim();
      const payload = await api(`/api/history?limit=200${q ? `&q=${encodeURIComponent(q)}` : ''}`);
      state.allHistory = payload.items;
      $('#historyTableBody').innerHTML = payload.items.length ? payload.items.map(item => rowHtml(item, true)).join('') : `<tr><td colspan="6" class="empty-table">${q ? 'No records match that filter.' : 'No scan history yet. Your scans will appear here.'}</td></tr>`;
      $('#historyCountLabel').textContent = `${payload.count} RECORD${payload.count === 1 ? '' : 'S'}`;
      $('#historyFooterCount').textContent = `Showing ${payload.count} of ${payload.count} loaded records`;
      bindRescan();
    } catch (error) { $('#historyTableBody').innerHTML = `<tr><td colspan="6" class="empty-table">${escapeHtml(error.message || 'Could not load history.')}</td></tr>`; }
  }
  let searchTimer = null;
  $('#historySearch').addEventListener('input', () => { window.clearTimeout(searchTimer); searchTimer = window.setTimeout(loadHistory, 220); });
  $('#exportButton').addEventListener('click', () => { window.location.href = '/api/history/export'; toast('Export started', 'A CSV file with your local scan records should download shortly.'); });
  $('#clearHistoryButton').addEventListener('click', async () => {
    if (!window.confirm('Clear all locally saved scan history? This cannot be undone.')) return;
    try { const result = await api('/api/history', {method:'DELETE'}); toast('History cleared', `${result.deleted} record${result.deleted===1?'':'s'} removed from this local workspace.`); await loadHistory(); await loadRecent(); await loadStats(); }
    catch (error) { toast('Could not clear history', error.message || 'Please try again.', 'error'); }
  });

  async function loadStats() {
    try {
      const stats = await api('/api/stats');
      $('#totalScans').textContent = formatNumber(stats.total_scans);
      $('#highRiskScans').textContent = formatNumber(stats.high_risk_total);
      renderLive(stats);
    } catch { $('#totalScans').textContent = '—'; $('#highRiskScans').textContent = '—'; }
  }
  async function loadModelInfo() {
    try {
      const m = await api('/api/model-info');
      $('#modelName').textContent = m.model_name || 'Local URL classifier';
      $('#modelHeroAccuracy').textContent = formatPercent(m.accuracy);
      $('#accuracyBar').style.width = `${Math.max(0, Math.min(100, (Number(m.accuracy) || 0) * 100))}%`;
      $('#precisionMetric').textContent = formatPercent(m.precision); $('#recallMetric').textContent = formatPercent(m.recall);
      $('#f1Metric').textContent = formatPercent(m.f1); $('#aucMetric').textContent = formatPercent(m.roc_auc);
      $('#datasetName').textContent = m.dataset || '—'; $('#sampleCount').textContent = formatNumber(m.samples_total);
      $('#splitName').textContent = m.split || '—'; $('#featureCount').textContent = formatNumber(m.feature_count);
    } catch (error) { toast('Model details unavailable', error.message || 'Could not read model information.', 'error'); }
  }
  async function initHealth() {
    try {
      const h = await api('/api/health');
      $('#sidebarEngine').textContent = h.model_loaded ? 'READY' : 'ERROR';
      $('#engineBadge').innerHTML = `<span class="pulse-dot" style="${h.model_loaded?'':'background:#9b3b35'}"></span><span>LOCAL ENGINE <strong style="${h.model_loaded?'':'color:#9b3b35'}">${h.model_loaded?'ONLINE':'ERROR'}</strong></span>`;
      if (!h.model_loaded) toast('Model not loaded', h.detail || 'Check the setup instructions.', 'error');
    } catch {
      $('#sidebarEngine').textContent = 'OFFLINE';
      $('#engineBadge').innerHTML = '<span class="pulse-dot" style="background:#e56b6b"></span><span>LOCAL ENGINE <strong style="color:#9b3b35">OFFLINE</strong></span>';
    }
  }
  $('#intelInfo').addEventListener('click', () => toast('External intelligence is not connected', 'This build uses URL syntax features and local indicators. A provider such as Google Safe Browsing must be configured explicitly to add live reputation checks.'));


  /* ---------- Benchmark + live charts (inline SVG, no external libraries) ---------- */
  const pct = (v, d = 2) => `${(v * 100).toFixed(d)}%`;
  const sgn = (v, d) => `${v >= 0 ? '+' : ''}${v.toFixed(d)}`;
  function gauge(score, tone) {
    const s = Math.max(0, Math.min(100, Number(score) || 0));
    const col = tone === 'high' ? '#9b3b35' : tone === 'medium' ? '#8f6417' : '#34694c';
    return `<div class="gauge ${tone}"><svg viewBox="0 0 124 70"><path d="M10 62A52 52 0 0 1 114 62" pathLength="100" stroke="#d5d7da" stroke-width="10" fill="none"/><path d="M10 62A52 52 0 0 1 114 62" pathLength="100" stroke="${col}" stroke-width="10" fill="none" stroke-dasharray="${s} 100"/></svg><strong>${s}<small style="font-size:13px">%</small></strong><span>phishing score</span></div>`;
  }
  const BM = [['accuracy','Accuracy'],['precision','Precision'],['recall','Recall (detection rate)'],['f1','F1-score'],['fpr','False positive rate (FPR)'],['fp','False positives (count)'],['fn','False negatives (count)'],['tp','True positives (count)'],['tn','True negatives (count)']];
  const LOWER_BETTER = new Set(['fpr','fp','fn']);
  function renderBenchmark(b) {
    const B = b.baseline, I = b.improved, rel = (k) => B[k] ? (I[k] - B[k]) / B[k] * 100 : 0;
    $('#benchN').textContent = Number(b.test_samples).toLocaleString();
    const kp = [['accuracy','Accuracy',true],['precision','Precision'],['f1','F1-score'],['fpr','False positive rate']];
    $('#kpis').innerHTML = kp.map(([k,l,lead]) => `<div class="kpi ${lead?'lead':''}"><div class="kpi-label">${l}</div><div class="kpi-val">${pct(I[k])}</div><div class="kpi-row"><span>was ${pct(B[k])}</span><span class="chip ${rel(k)>0?'up':'down'}">${sgn(rel(k),2)}%</span></div></div>`).join('');
    const mt = [['accuracy','Accuracy'],['precision','Precision'],['recall','Recall'],['f1','F1-score']], y = (v) => 200 - ((v * 100 - 80) / 20) * 170;
    let g = [80,85,90,95,100].map(t => `<line x1="34" x2="500" y1="${y(t/100)}" y2="${y(t/100)}" stroke="#c4c6ca" stroke-dasharray="${t===80?0:3}"/><text x="26" y="${y(t/100)+4}" text-anchor="end">${t}</text>`).join('');
    mt.forEach(([k,l], n) => { const x = 54 + n * 114;
      [[B[k],'#b9bcc1',''],[I[k],'#2a2d32','i']].forEach(([v,c,cls], m) => { const bx = x + m * 42, top = y(v);
        g += `<rect class="bar ${cls}" x="${bx}" y="${top}" width="38" height="${200-top}" rx="3" fill="${c}"/><text class="val" x="${bx+19}" y="${top-6}" text-anchor="middle">${(v*100).toFixed(1)}</text>`; });
      g += `<text x="${x+40}" y="220" text-anchor="middle">${l}</text>`; });
    $('#barChart').innerHTML = `<svg viewBox="0 0 510 230" role="img" aria-label="Grouped bar chart comparing baseline and improved accuracy, precision, recall and F1">${g}</svg>`;
    const cm = (m, t) => { const c = (k, lab, ok) => `<div style="background:${ok?'#2a2d32':'#efd9d6'};color:${ok?'#f6f6f7':'#9b3b35'}"><b>${m[k].toLocaleString()}</b><span>${lab}</span></div>`;
      return `<div><div class="cm-title">${t}</div><div class="cm">${c('tn','True neg.',1)}${c('fp','False pos.',0)}${c('fn','False neg.',0)}${c('tp','True pos.',1)}</div></div>`; };
    $('#matrices').innerHTML = cm(B,'Baseline') + cm(I,'Improved');
    $('#cmpBody').innerHTML = BM.map(([k,l]) => { const d = I[k] - B[k], r = rel(k), cnt = ['fp','fn','tp','tn'].includes(k), fmt = (v) => v.toFixed(6);
      const good = d === 0 ? 'flat' : ((LOWER_BETTER.has(k) ? d < 0 : d > 0) ? 'good' : '');
      return `<tr><td>${l}</td><td>${fmt(B[k])}</td><td class="imp">${fmt(I[k])}</td><td class="${good}">${fmt(d)}</td><td class="${good} pos">${sgn(r,2)}%</td></tr>`; }).join('');
    const rescued = B.fp - I.fp;
    $('#findings').innerHTML = `<div class="finding"><strong>${Math.abs(rel('fp')).toFixed(2)}%</strong><p>False positives reduced <b>(rescued ${rescued} legitimate URLs)</b></p></div><div class="finding"><strong>${(I.precision*100).toFixed(1)}%</strong><p>Precision shifted from <b>${pct(B.precision)}</b> to <b>${pct(I.precision)}</b></p></div><div class="finding"><strong>${(I.recall*100).toFixed(1)}%</strong><p>Detection rate unchanged: <b>${I.fn} phishing URLs</b> are still missed</p></div>`;
    const mx = Math.max(B.fp, I.fp);
    $('#fpBars').innerHTML = [['Baseline',B.fp,'b'],['Improved',I.fp,'']].map(([l,v,c]) => `<div class="hbar ${c}"><span>${l}</span><div><i style="width:${v/mx*100}%"></i></div><b>${v}</b></div>`).join('');
    $('#benchNote').textContent = b.note || '';
  }
  function renderLive(st) {
    $('#last24').textContent = formatNumber(st.scans_last_24h);
    const rc = st.risk_counts || {}, tot = (rc.High||0) + (rc.Moderate||0) + (rc.Lower||0), segs = [['High','#9b3b35'],['Moderate','#8f6417'],['Lower','#34694c']];
    let off = 0, ring = `<circle cx="52" cy="52" r="40" fill="none" stroke="#d5d7da" stroke-width="14"/>`;
    if (tot) segs.forEach(([k,c]) => { const f = (rc[k]||0) / tot * 100; if (f) { ring += `<circle cx="52" cy="52" r="40" fill="none" stroke="${c}" stroke-width="14" pathLength="100" stroke-dasharray="${f} ${100-f}" stroke-dashoffset="${-off}" transform="rotate(-90 52 52)"/>`; off += f; } });
    $('#riskDonut').innerHTML = `<svg viewBox="0 0 104 104" role="img" aria-label="Risk mix of saved scans">${ring}</svg><div class="dl">${tot ? segs.map(([k,c]) => `<span><i style="background:${c}"></i>${k}: <b>${rc[k]||0}</b></span>`).join('') : '<span>No scans yet. Analyze a URL to fill this chart.</span>'}</div>`;
    const d = st.daily || [], mx = Math.max(1, ...d.map(x => x.count));
    $('#dailyBars').innerHTML = `<svg viewBox="0 0 280 120">${d.map((x,i) => { const h = x.count / mx * 78; return `<rect x="${8+i*38}" y="${90-h}" width="26" height="${Math.max(h,2)}" rx="3" fill="${x.count?'#2a2d32':'#c4c6ca'}"/><text class="val" x="${21+i*38}" y="${84-h}" text-anchor="middle">${x.count||''}</text><text x="${21+i*38}" y="108" text-anchor="middle">${new Date(x.day+'T00:00:00Z').toLocaleDateString([], {weekday:'short', timeZone:'UTC'})}</text>`; }).join('')}</svg>`;
  }
  async function loadBenchmark() { try { renderBenchmark(await api('/api/benchmark')); } catch (e) { $('#kpis').innerHTML = `<div class="panel card" style="grid-column:1/-1">Benchmark unavailable: ${escapeHtml(e.message)}</div>`; } }

  const dateText = formatDate(); $('#todayLabel').textContent = dateText;
  loadStats(); loadRecent(); initHealth(); loadBenchmark();
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    window.addEventListener('load', () => navigator.serviceWorker.register('/static/service-worker.js').catch(() => {}));
  }
  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault(); state.deferredInstall = event; $('#installButton').hidden = false;
  });
  $('#installButton').addEventListener('click', async () => {
    if (!state.deferredInstall) { toast('Install availability', 'Use your browser menu and choose “Install app” or “Add to Home Screen” when offered.'); return; }
    state.deferredInstall.prompt(); await state.deferredInstall.userChoice; state.deferredInstall = null; $('#installButton').hidden = true;
  });
  window.addEventListener('appinstalled', () => { $('#installButton').hidden = true; toast('App installed', 'IoTPhish Guard is now available from your app launcher.'); });
})();
