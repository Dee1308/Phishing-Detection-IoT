"""Train the project's CNN-LSTM (Conv1D32 -> Conv1D64 -> MaxPool -> Dropout -> LSTM128 -> Dropout -> Dense) in pure NumPy.

Same architecture and PyTorch parameter layout as train_model.py, for machines where PyTorch is unavailable.
Output weights go to artifacts/cnn_lstm_model.npz, which app/model.py loads into the PyTorch module.
Usage: python scripts/train_without_torch.py [--check]   (resumable: progress is checkpointed every epoch)"""
import sys, json, time, pickle, os
from pathlib import Path
import numpy as np, pandas as pd, joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from app.features import FEATURE_COLUMNS, extract_url_features
sig = lambda x: 1 / (1 + np.exp(-x))

def init(rng):
    u = lambda b, *s: rng.uniform(-b, b, s).astype(np.float64)
    return {'conv1.weight': u(1/np.sqrt(3), 32, 1, 3), 'conv1.bias': u(1/np.sqrt(3), 32), 'conv2.weight': u(1/np.sqrt(96), 64, 32, 3), 'conv2.bias': u(1/np.sqrt(96), 64),
            'lstm.weight_ih_l0': u(.0884, 512, 64), 'lstm.weight_hh_l0': u(.0884, 512, 128), 'lstm.bias_ih_l0': u(.0884, 512), 'lstm.bias_hh_l0': u(.0884, 512),
            'out.weight': u(.0884, 1, 128), 'out.bias': u(.0884, 1)}

def conv(x, w, b):
    L = x.shape[2]; xp = np.pad(x, ((0,0),(0,0),(1,1))); o = sum(np.einsum('ncl,oc->nol', xp[:,:,k:k+L], w[:,:,k]) for k in range(3))
    return o + b[None,:,None], xp
def conv_back(dz, xp, w):
    L = dz.shape[2]; dw = np.stack([np.einsum('ncl,nol->oc', xp[:,:,k:k+L], dz) for k in range(3)], 2)
    dxp = sum(np.pad(np.einsum('nol,oc->ncl', dz, w[:,:,k]), ((0,0),(0,0),(k,2-k))) for k in range(3))
    return dw, dz.sum((0,2)), dxp[:,:,1:-1]

def forward(P, X, rng=None):
    c = {}; x = X[:,None,:]; z1, c['xp1'] = conv(x, P['conv1.weight'], P['conv1.bias']); a1 = np.maximum(z1, 0)
    z2, c['xp2'] = conv(a1, P['conv2.weight'], P['conv2.bias']); a2 = np.maximum(z2, 0); c['z1'], c['z2'] = z1, z2
    N, C, L = a2.shape; r = a2[:,:,:L//2*2].reshape(N, C, L//2, 2); c['arg'] = r.argmax(3); p = r.max(3)
    c['m1'] = (rng.random(p.shape) >= .25) / .75 if rng is not None else np.ones_like(p); s = (p * c['m1']).transpose(0,2,1); c['L'] = L
    Wi, Wh, b = P['lstm.weight_ih_l0'], P['lstm.weight_hh_l0'], P['lstm.bias_ih_l0'] + P['lstm.bias_hh_l0']
    h = np.zeros((N,128)); cs = np.zeros((N,128)); c['s'] = s; c['steps'] = []
    for t in range(s.shape[1]):
        g = s[:,t] @ Wi.T + h @ Wh.T + b; i, f, gg, o = sig(g[:,:128]), sig(g[:,128:256]), np.tanh(g[:,256:384]), sig(g[:,384:])
        cn = f * cs + i * gg; hn = o * np.tanh(cn); c['steps'].append((h, cs, i, f, gg, o, cn)); h, cs = hn, cn
    c['m2'] = (rng.random(h.shape) >= .5) / .5 if rng is not None else np.ones_like(h); c['h'] = h * c['m2']
    return (c['h'] @ P['out.weight'].T + P['out.bias'])[:,0], c

def backward(P, c, y, logit):
    G = {k: np.zeros_like(v) for k, v in P.items()}; N = len(y); dl = (sig(logit) - y)[:,None] / N
    G['out.weight'] = dl.T @ c['h']; G['out.bias'] = dl.sum(0); dh = (dl @ P['out.weight']) * c['m2']; dc = np.zeros_like(dh)
    Wi, Wh = P['lstm.weight_ih_l0'], P['lstm.weight_hh_l0']; ds = np.zeros_like(c['s'])
    for t in range(len(c['steps']) - 1, -1, -1):
        hp, cp, i, f, gg, o, cn = c['steps'][t]; tc = np.tanh(cn); do = dh * tc; dc = dc + dh * o * (1 - tc**2)
        dg = np.concatenate([dc*gg*i*(1-i), dc*cp*f*(1-f), dc*i*(1-gg**2), do*o*(1-o)], 1)
        G['lstm.weight_ih_l0'] += dg.T @ c['s'][:,t]; G['lstm.weight_hh_l0'] += dg.T @ hp; G['lstm.bias_ih_l0'] += dg.sum(0); ds[:,t] = dg @ Wi; dh = dg @ Wh; dc = dc * f
    G['lstm.bias_hh_l0'] = G['lstm.bias_ih_l0'].copy()
    dp = ds.transpose(0,2,1) * c['m1']; N_, C, Lh = dp.shape; da2 = np.zeros((N_, C, c['L']))
    oh = np.zeros((N_, C, Lh, 2)); np.put_along_axis(oh, c['arg'][...,None], dp[...,None], 3); da2[:,:,:Lh*2] = oh.reshape(N_, C, Lh*2)
    dz2 = da2 * (c['z2'] > 0); G['conv2.weight'], G['conv2.bias'], da1 = conv_back(dz2, c['xp2'], P['conv2.weight'])
    dz1 = da1 * (c['z1'] > 0); G['conv1.weight'], G['conv1.bias'], _ = conv_back(dz1, c['xp1'], P['conv1.weight'])
    return G

def bce(P, X, y):
    z, _ = forward(P, X); return np.mean(np.maximum(z, 0) - z * y + np.log1p(np.exp(-abs(z))))

def gradcheck():
    rng = np.random.default_rng(0); P = init(rng); X = rng.normal(size=(6, 52)); y = (rng.random(6) > .5).astype(float)
    z, c = forward(P, X); G = backward(P, c, y, z); worst = 0
    for k in P:
        for _ in range(4):
            ix = tuple(rng.integers(0, s) for s in P[k].shape); old = P[k][ix]; e = 1e-5
            P[k][ix] = old + e; a = bce(P, X, y); P[k][ix] = old - e; b = bce(P, X, y); P[k][ix] = old
            ref = G['lstm.bias_ih_l0'][ix] if k == 'lstm.bias_hh_l0' else G[k][ix]; num = (a - b) / (2 * e)
            worst = max(worst, abs(ref - num) / max(1e-7, abs(ref) + abs(num)))
    print('gradient check, worst relative error: %.2e' % worst); return worst

def main(epochs=40, budget=None):
    seed = 42; rng = np.random.default_rng(seed); df = pd.read_csv(ROOT/'data'/'dataset_B_05_2020.csv'); cols = list(FEATURE_COLUMNS); rows, keep = [], []
    for i, u in enumerate(df['url']):
        try: rows.append([extract_url_features(u)[1].get(c, 0.0) for c in cols]); keep.append(i)
        except ValueError: pass
    X = np.nan_to_num(np.array(rows, dtype=np.float64)); y = df['status'].astype(str).str.lower().eq('phishing').to_numpy(float)[keep]
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=.30, random_state=seed, stratify=y); sc = StandardScaler(); Xtr = sc.fit_transform(Xtr); Xte = sc.transform(Xte)
    P = init(rng); m = {k: np.zeros_like(v) for k, v in P.items()}; v2 = {k: np.zeros_like(v) for k, v in P.items()}; step = 0; t0 = time.time(); start = 0
    ck = ROOT/'artifacts'/'.train_ckpt.pkl'
    if ck.exists(): P, m, v2, step, start, rng = pickle.loads(ck.read_bytes()); print('resuming at epoch', start + 1)
    for ep in range(start, epochs):
        if budget and time.time() - t0 > budget: print('paused; run again to continue'); return
        order = rng.permutation(len(Xtr)); tot = 0
        for s in range(0, len(order), 256):
            ix = order[s:s+256]; z, c = forward(P, Xtr[ix], rng); G = backward(P, c, ytr[ix], z); step += 1; tot += bce(P, Xtr[ix], ytr[ix]) * len(ix)
            for k in P:
                m[k] = .9*m[k] + .1*G[k]; v2[k] = .999*v2[k] + .001*G[k]**2; P[k] -= .001 * (m[k]/(1-.9**step)) / (np.sqrt(v2[k]/(1-.999**step)) + 1e-8)
        ck.write_bytes(pickle.dumps((P, m, v2, step, ep + 1, rng)))
        pr = sig(forward(P, Xte)[0]); print(f'Epoch {ep+1}/{epochs} loss {tot/len(Xtr):.4f} test-acc {((pr>=.5)==yte).mean():.4f} ({time.time()-t0:.0f}s)', flush=True)
    pr = sig(forward(P, Xte)[0]); pred = (pr >= .5).astype(int); cm = confusion_matrix(yte, pred).tolist(); ART = ROOT/'artifacts'
    np.savez(ART/'cnn_lstm_model.npz', **{k: v.astype('float32') for k, v in P.items()}); joblib.dump({'scaler': sc, 'features': cols}, ART/'preprocessing.joblib')
    old = json.loads((ART/'model_metrics.json').read_text()); old.update({'model_name': 'CNN-LSTM (URL-feature model)', 'dataset': 'dataset_B_05_2020.csv (URL-derived features only)',
      'excluded_features': '35 content/network columns that cannot be derived from a URL', 'samples_total': int(len(y)), 'samples_train': int(len(ytr)), 'samples_test': int(len(yte)), 'feature_count': len(cols), 'features': cols,
      'accuracy': float(accuracy_score(yte, pred)), 'precision': float(precision_score(yte, pred)), 'recall': float(recall_score(yte, pred)), 'f1': float(f1_score(yte, pred)), 'roc_auc': float(roc_auc_score(yte, pr)),
      'confusion_matrix': {'true_negative': cm[0][0], 'false_positive': cm[0][1], 'false_negative': cm[1][0], 'true_positive': cm[1][1]},
      'limitations': ['Hold-out benchmark metrics are not a guarantee of real-world performance.', 'This model sees only the URL string. Page content, DNS, WHOIS and reputation signals are not used, so it is a triage signal, not a verdict.', 'Threat-intelligence checks are not live. The original notebook’s simulated false-positive override is not represented as a real API.']})
    (ART/'model_metrics.json').write_text(json.dumps(old, indent=2)); ck.unlink(missing_ok=True); print({k: round(old[k], 4) for k in ('accuracy', 'precision', 'recall', 'f1', 'roc_auc')}, cm)

if __name__ == '__main__':
    if '--check' in sys.argv: sys.exit(0 if gradcheck() < 1e-4 else 1)
    main(budget=int(os.environ.get('TRAIN_BUDGET', 0)) or None)
