"""IoTPhish Guard application package."""
