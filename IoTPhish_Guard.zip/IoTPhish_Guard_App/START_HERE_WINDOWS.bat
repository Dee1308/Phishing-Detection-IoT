@echo off
setlocal
cd /d "%~dp0"
echo =====================================================
echo   IoTPhish Guard - local website setup
echo =====================================================
echo.
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher ^(py^) was not found. Install Python 3.11+ and enable Add Python to PATH.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo Creating a virtual environment...
  py -m venv .venv
  if errorlevel 1 goto :error
)
call ".venv\Scripts\activate.bat"
echo Installing or checking requirements...
python -m pip install --upgrade pip
if errorlevel 1 goto :error
pip install -r requirements.txt
if errorlevel 1 goto :error
echo.
echo Starting IoTPhish Guard at http://127.0.0.1:8000
echo Keep this window open while using the website. Press Ctrl+C to stop.
echo.
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
pause
exit /b 0
:error
echo.
echo Setup failed. Check the Python installation and your internet connection, then retry.
pause
exit /b 1
