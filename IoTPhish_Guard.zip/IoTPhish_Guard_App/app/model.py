"""Inference wrapper for the project's CNN-LSTM model."""
from pathlib import Path
import torch
from torch import nn
import joblib
ROOT=Path(__file__).resolve().parents[1]
class CNNLSTM(nn.Module):
    def __init__(self):
        super().__init__(); self.conv1=nn.Conv1d(1,32,3,padding=1); self.conv2=nn.Conv1d(32,64,3,padding=1); self.pool=nn.MaxPool1d(2); self.drop1=nn.Dropout(.25); self.lstm=nn.LSTM(64,128,batch_first=True); self.drop2=nn.Dropout(.5); self.out=nn.Linear(128,1)
    def forward(self,x):
        x=torch.relu(self.conv1(x)); x=torch.relu(self.conv2(x)); x=self.drop1(self.pool(x)); x=x.transpose(1,2); _,(h,_)=self.lstm(x); return self.out(self.drop2(h[-1])).squeeze(1)
class CNNLSTMPredictor:
    def __init__(self):
        bundle=joblib.load(ROOT/'artifacts'/'preprocessing.joblib'); self.scaler=bundle['scaler']; self.features=bundle['features']; art=ROOT/'artifacts'; pt,npz=art/'cnn_lstm_model.pt',art/'cnn_lstm_model.npz'  # use whichever trainer ran most recently
        self.model=CNNLSTM()
        if npz.exists() and (not pt.exists() or npz.stat().st_mtime>=pt.stat().st_mtime):
            import numpy as _np; w=_np.load(npz); self.model.load_state_dict({k:torch.from_numpy(w[k]) for k in w.files})
        else:
            self.model.load_state_dict(torch.load(pt,map_location='cpu',weights_only=True)['state_dict'])
        self.model.eval()
    def predict_proba(self,frame):
        import numpy as np
        X=frame.reindex(columns=self.features).apply(__import__('pandas').to_numeric,errors='coerce').to_numpy(dtype='float64'); X=np.where(np.isnan(X),self.scaler.mean_[None,:],X)  # unknown inputs become the training average (neutral), never 0
        X=self.scaler.transform(X).astype('float32')
        with torch.no_grad(): p=torch.sigmoid(self.model(torch.tensor(X).unsqueeze(1))).numpy()
        return np.column_stack([1-p,p])
