from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app import main


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setattr(main, "DB_PATH", tmp_path / "test_history.sqlite3")
    main._init_db()
    with TestClient(main.app) as test_client:
        yield test_client


def test_health_and_model_info(client):
    health = client.get("/api/health")
    assert health.status_code == 200
    assert health.json()["model_loaded"] is True
    info = client.get("/api/model-info").json()
    assert info["feature_count"] == 52
    assert info["accuracy"] > 0.80


def test_scan_normalizes_and_saves_history(client):
    response = client.post("/api/scan", json={"url": "www.nasa.gov"})
    assert response.status_code == 200
    result = response.json()["result"]
    assert result["url"].startswith("https://")
    assert result["hostname"] == "www.nasa.gov"
    assert 0 <= result["score_percent"] <= 100
    assert result["findings"]
    history = client.get("/api/history").json()["items"]
    assert len(history) == 1
    assert history[0]["url"] == result["url"]


def test_rejects_unsafe_scheme(client):
    response = client.post("/api/scan", json={"url": "javascript:alert(1)"})
    assert response.status_code == 422


def test_batch_scan_and_export(client):
    response = client.post("/api/scan/batch", json={"urls": ["https://example.com", "http://192.168.1.25/login"]})
    assert response.status_code == 200
    assert response.json()["count"] == 2
    exported = client.get("/api/history/export")
    assert exported.status_code == 200
    assert "text/csv" in exported.headers["content-type"]
    assert "created_at_utc" in exported.text


def test_frontend_serves(client):
    response = client.get("/")
    assert response.status_code == 200
    assert "IoTPhish Guard" in response.text


def test_embedded_credentials_are_removed_before_history(client):
    response = client.post("/api/scan", json={"url": "https://student:secret@example.com/login"})
    assert response.status_code == 200
    result = response.json()["result"]
    assert "secret" not in result["url"]
    assert "student" not in result["url"]
    assert "@" in result["url"]
    assert "secret" not in client.get("/api/history").text


def test_benchmark_matches_notebook(client):
    b = client.get("/api/benchmark").json()
    assert b["baseline"]["accuracy"] == 0.934092 and b["improved"]["accuracy"] == 0.952173
    assert b["baseline"]["fp"] - b["improved"]["fp"] == 62
    assert sum(b["improved"][k] for k in ("tp", "tn", "fp", "fn")) == b["test_samples"]
    stats = client.get("/api/stats").json()
    assert len(stats["daily"]) == 7 and set(stats["risk_counts"]) == {"High", "Moderate", "Lower"}


def test_scores_are_spread_across_tiers(client):
    """Regression: zero-filled content features once made every URL High risk."""
    tier = lambda u: client.post("/api/scan", json={"url": u}).json()["risk_tier"]
    assert tier("https://www.wikipedia.org") == "Lower"
    assert tier("http://secure-paypa1-login.verify-account.top/signin?id=3829") == "High"
