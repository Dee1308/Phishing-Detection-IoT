"""URL-only feature extraction aligned to the supplied phishing URL dataset.

This module deliberately does not visit the submitted URL. Page-content, DNS,
WHOIS, redirect-chain and reputation checks need separately configured services
and are not inferred from URL syntax.
"""
from __future__ import annotations

import ipaddress
import json
import re
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]

HINTS = [
    "wp", "login", "includes", "admin", "content", "site", "images", "js",
    "alibaba", "css", "myaccount", "dropbox", "themes", "plugins", "signin", "view",
]
SUSPICIOUS_TLDS = {
    "fit", "tk", "gp", "ga", "work", "ml", "date", "wang", "men", "icu",
    "online", "click", "country", "stream", "download", "xin", "racing", "jetzt",
    "ren", "mom", "party", "review", "trade", "accountants", "science", "ninja",
    "xyz", "faith", "zip", "cricket", "win", "accountant", "realtor", "top",
    "christmas", "gdn", "link", "asia", "club", "la", "exposed", "pe", "audio",
    "website", "media",
}
SHORTENERS = {
    "bit.ly", "goo.gl", "shorte.st", "go2l.ink", "x.co", "ow.ly", "t.co", "tinyurl.com",
    "tr.im", "is.gd", "cli.gs", "yfrog.com", "migre.me", "ff.im", "tiny.cc", "url4.eu",
    "twit.ac", "su.pr", "twurl.nl", "snipurl.com", "short.to", "budurl.com", "ping.fm",
    "post.ly", "just.as", "bkite.com", "snipr.com", "fic.kr", "loopt.us", "doiop.com",
    "short.ie", "kl.am", "wp.me", "rubyurl.com", "om.ly", "to.ly", "bit.do", "lnkd.in",
    "db.tt", "qr.ae", "adf.ly", "cur.lv", "ity.im", "q.gs", "po.st", "bc.vc", "u.to",
    "j.mp", "buzurl.com", "cutt.us", "yourls.org", "prettylinkpro.com", "v.gd", "link.zip.net",
}
MULTI_PART_SUFFIXES = {
    "co.uk", "org.uk", "ac.uk", "gov.uk", "com.au", "net.au", "org.au", "edu.au",
    "co.in", "firm.in", "net.in", "org.in", "gen.in", "ind.in", "com.sg", "com.my",
    "co.nz", "com.br", "com.mx", "co.za", "co.jp", "ne.jp", "or.jp", "com.cn",
}

try:
    _brand_path = ROOT / "data" / "allbrands.txt"
    BRANDS = {x.strip().lower() for x in _brand_path.read_text(encoding="utf-8", errors="ignore").splitlines() if x.strip()}
except OSError:
    BRANDS = set()

# Feature columns deliberately mirror the URL-derived subset in dataset_B_05_2020.csv.
FEATURE_COLUMNS = [
    "length_url", "length_hostname", "ip", "nb_dots", "nb_hyphens", "nb_at", "nb_qm",
    "nb_and", "nb_or", "nb_eq", "nb_underscore", "nb_tilde", "nb_percent", "nb_slash",
    "nb_star", "nb_colon", "nb_comma", "nb_semicolumn", "nb_dollar", "nb_space", "nb_www",
    "nb_com", "nb_dslash", "http_in_path", "https_token", "ratio_digits_url", "ratio_digits_host",
    "punycode", "port", "tld_in_path", "tld_in_subdomain", "abnormal_subdomain", "nb_subdomains",
    "prefix_suffix", "shortening_service", "path_extension", "length_words_raw", "char_repeat",
    "shortest_words_raw", "shortest_word_host", "shortest_word_path", "longest_words_raw",
    "longest_word_host", "longest_word_path", "avg_words_raw", "avg_word_host", "avg_word_path",
    "phish_hints", "domain_in_brand", "brand_in_subdomain", "brand_in_path", "suspecious_tld",
]


def normalize_url(raw_url: str) -> str:
    """Validate and normalize a user-supplied HTTP(S) URL without network access."""
    if not isinstance(raw_url, str):
        raise ValueError("Enter a URL as text.")
    value = raw_url.strip()
    if not value:
        raise ValueError("Enter a URL to analyze.")
    if len(value) > 2048:
        raise ValueError("The URL is too long. Use a URL under 2,048 characters.")
    if any(ord(ch) < 32 for ch in value):
        raise ValueError("The URL contains control characters.")
    if re.match(r"^(?:javascript|data|file|ftp|mailto|tel):", value, flags=re.IGNORECASE):
        raise ValueError("Only HTTP and HTTPS URLs can be analyzed.")
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", value):
        value = "https://" + value
    parsed = urlsplit(value)
    if parsed.scheme.lower() not in {"http", "https"}:
        raise ValueError("Only HTTP and HTTPS URLs can be analyzed.")
    if not parsed.hostname:
        raise ValueError("That does not look like a complete URL. Include a domain name.")
    try:
        hostname = parsed.hostname.encode("idna").decode("ascii").lower().rstrip(".")
    except UnicodeError as exc:
        raise ValueError("The domain contains invalid international characters.") from exc
    if not hostname or " " in hostname:
        raise ValueError("Please enter a valid domain name.")
    # Reconstruct without user-info. Userinfo stays part of the inspected string and is a signal,
    # but is never forwarded anywhere. Preserve query/path/fragment for feature analysis.
    netloc = hostname
    try:
        explicit_port = parsed.port
    except ValueError as exc:
        raise ValueError("The URL contains an invalid port number.") from exc
    if explicit_port is not None:
        netloc += f":{explicit_port}"
    if parsed.username is not None or parsed.password is not None:
        # Keep the @ indicator for model analysis but discard embedded credentials before
        # the normalized URL is returned or persisted in local history.
        netloc = "@" + netloc
    return parsed.scheme.lower() + "://" + netloc + (parsed.path or "") + (("?" + parsed.query) if parsed.query else "") + (("#" + parsed.fragment) if parsed.fragment else "")


def _registered_parts(hostname: str) -> tuple[str, str, str]:
    """Approximate public-suffix splitting using common multi-label suffixes."""
    host = hostname.lower().strip(".")
    labels = host.split(".") if host else []
    if not labels:
        return "", "", ""
    try:
        ipaddress.ip_address(host)
        return host, "", ""
    except ValueError:
        pass
    if len(labels) >= 3 and ".".join(labels[-2:]) in MULTI_PART_SUFFIXES:
        suffix = ".".join(labels[-2:])
        domain = labels[-3]
        subdomain = ".".join(labels[:-3])
    elif len(labels) >= 2:
        suffix = labels[-1]
        domain = labels[-2]
        subdomain = ".".join(labels[:-2])
    else:
        suffix, domain, subdomain = labels[-1], labels[-1], ""
    return domain, subdomain, suffix


def _split_words(value: str) -> list[str]:
    return [x for x in re.split(r"[-./?=@&%:_]", (value or "").lower()) if x]


def _word_stats(words: list[str]) -> tuple[int, int, int, float]:
    if not words:
        return 0, 0, 0, 0.0
    lengths = [len(x) for x in words]
    return min(lengths), max(lengths), len(words), sum(lengths) / len(words)


def _char_repeat(words: list[str]) -> int:
    count = 0
    for word in words:
        for size in (2, 3, 4, 5):
            count += sum(1 for i in range(len(word) - size + 1) if len(set(word[i:i + size])) == 1)
    return count


def extract_url_features(raw_url: str) -> tuple[str, dict[str, float]]:
    """Return the normalized URL and numeric features in the model's expected order."""
    url = normalize_url(raw_url)
    parsed = urlsplit(url)
    hostname = (parsed.hostname or "").lower().rstrip(".")
    domain, subdomain, tld = _registered_parts(hostname)
    path = parsed.path or ""
    if parsed.query:
        path += "?" + parsed.query
    if parsed.fragment:
        path += "#" + parsed.fragment
    full = url.lower()
    raw_words = _split_words(domain) + _split_words(path) + _split_words(subdomain)
    host_words = _split_words(domain) + _split_words(subdomain)
    path_words = _split_words(path)
    short_raw, long_raw, _n_raw, avg_raw = _word_stats(raw_words)
    short_host, long_host, _n_host, avg_host = _word_stats(host_words)
    short_path, long_path, _n_path, avg_path = _word_stats(path_words)
    digit_url = sum(ch.isdigit() for ch in full)
    digit_host = sum(ch.isdigit() for ch in hostname)
    try:
        ipaddress.ip_address(hostname)
        has_ip = 1
    except ValueError:
        has_ip = int(bool(re.search(r"(?:\d{1,3}\.){3}\d{1,3}", full)))
    try:
        port = int(parsed.port is not None)
    except ValueError:
        port = 1
    # Domain-level indicators are used as explainable URL signals, not reputation verdicts.
    hints = sum(url.lower().count(hint) for hint in HINTS)
    brand_in_path = int(any(("." + brand + ".") in path.lower() for brand in BRANDS if brand))
    brand_in_subdomain = int(any(("." + brand + ".") in subdomain.lower() for brand in BRANDS if brand))
    domain_in_brand = int(domain.lower() in BRANDS)
    suspicious_tld = int(tld.lower() in SUSPICIOUS_TLDS)
    domain_for_shortener = hostname
    is_shortener = int(any(s in domain_for_shortener for s in SHORTENERS))
    last_dslash = full.rfind("//")
    dot_count = full.count(".")
    ratio_digits_url = digit_url / max(len(full), 1)
    ratio_digits_host = digit_host / max(len(hostname), 1)
    try:
        is_punycode = int(any(label.startswith("xn--") for label in hostname.split(".")))
    except Exception:
        is_punycode = 0
    features: dict[str, float] = {
        "length_url": len(url),
        "length_hostname": len(hostname),
        "ip": has_ip,
        "nb_dots": dot_count,
        "nb_hyphens": full.count("-"),
        "nb_at": full.count("@"),
        "nb_qm": full.count("?"),
        "nb_and": full.count("&"),
        "nb_or": full.count("|"),
        "nb_eq": full.count("="),
        "nb_underscore": full.count("_"),
        "nb_tilde": int("~" in full),
        "nb_percent": full.count("%"),
        "nb_slash": full.count("/"),
        "nb_star": full.count("*"),
        "nb_colon": full.count(":"),
        "nb_comma": full.count(","),
        "nb_semicolumn": full.count(";"),
        "nb_dollar": full.count("$"),
        "nb_space": full.count(" ") + full.count("%20"),
        "nb_www": sum("www" in word for word in raw_words),
        "nb_com": sum("com" in word for word in raw_words),
        "nb_dslash": int(last_dslash > 6),
        "http_in_path": path.lower().count("http"),
        "https_token": int(parsed.scheme.lower() != "https"),
        "ratio_digits_url": ratio_digits_url,
        "ratio_digits_host": ratio_digits_host,
        "punycode": is_punycode,
        "port": port,
        "tld_in_path": int(bool(tld) and tld in path.lower()),
        "tld_in_subdomain": int(bool(tld) and tld in subdomain.lower()),
        "abnormal_subdomain": int(bool(re.search(r"https?://(w[w]?|\d)([w]?\d|-)", full))),
        "nb_subdomains": 1 if dot_count == 1 else 2 if dot_count == 2 else 3,
        "prefix_suffix": int(bool(re.findall(r"https?://[^\-]+-[^\-]+/", full))),
        "shortening_service": is_shortener,
        "path_extension": int((parsed.path or "").lower().endswith(".txt")),
        "length_words_raw": len(raw_words),
        "char_repeat": _char_repeat(raw_words),
        "shortest_words_raw": short_raw,
        "shortest_word_host": short_host,
        "shortest_word_path": short_path,
        "longest_words_raw": long_raw,
        "longest_word_host": long_host,
        "longest_word_path": long_path,
        "avg_words_raw": avg_raw,
        "avg_word_host": avg_host,
        "avg_word_path": avg_path,
        "phish_hints": hints,
        "domain_in_brand": domain_in_brand,
        "brand_in_subdomain": brand_in_subdomain,
        "brand_in_path": brand_in_path,
        "suspecious_tld": suspicious_tld,
    }
    ordered = {key: float(features.get(key, 0.0)) for key in FEATURE_COLUMNS}
    return url, ordered


def explain_url_features(url: str, features: dict[str, float]) -> list[dict[str, str]]:
    """Generate factual, human-readable URL syntax findings."""
    parsed = urlsplit(url)
    hostname = (parsed.hostname or "").lower()
    domain, subdomain, tld = _registered_parts(hostname)
    findings: list[dict[str, str]] = []
    def add(level: str, title: str, detail: str) -> None:
        findings.append({"level": level, "title": title, "detail": detail})

    if features.get("ip", 0): add("high", "IP address in host", "The destination is specified as an IP address rather than a conventional domain.")
    if features.get("nb_at", 0): add("high", "At-sign in URL", "An @ symbol can make the text before it look like the destination while the browser opens the host after it.")
    if features.get("punycode", 0): add("medium", "Internationalized domain encoding", "The hostname contains an xn-- label. Check carefully for look-alike characters.")
    if features.get("shortening_service", 0): add("medium", "URL shortener pattern", "The host resembles a known URL-shortening service, so the final destination is not visible from this URL alone.")
    if features.get("brand_in_path", 0) and not features.get("domain_in_brand", 0): add("high", "Brand-like text outside the registered name", "A familiar brand string appears in the URL path or subdomain but is not the registered domain name.")
    if features.get("suspecious_tld", 0): add("medium", "Higher-risk TLD pattern", f"The top-level domain .{tld} appears in the project's locally configured TLD indicator list; this alone does not prove maliciousness.")
    if features.get("nb_subdomains", 0) >= 3 or hostname.count(".") >= 4: add("medium", "Deeply nested hostname", "Several hostname labels can obscure the actual registered domain.")
    if features.get("length_url", 0) >= 120: add("medium", "Unusually long URL", "The URL is long enough to hide misleading names or parameters; length alone is not proof of phishing.")
    if features.get("ratio_digits_host", 0) >= 0.2: add("medium", "Many digits in hostname", "A high digit ratio can occur in machine-generated or deceptive hostnames.")
    if features.get("nb_hyphens", 0) >= 3: add("low", "Multiple hyphens", "The URL contains multiple hyphens. Review the full registered domain rather than relying on brand words.")
    if features.get("phish_hints", 0) >= 2: add("medium", "Account / login-related wording", "The URL contains several common path hints such as login, admin, or myaccount.")
    if features.get("https_token", 0): add("low", "Not using HTTPS", "The URL does not use HTTPS. HTTPS alone does not determine whether a site is legitimate.")
    if not findings: add("low", "No strong syntax indicators found", "No high-signal URL patterns from the local rule set were detected. A clean-looking URL can still be malicious.")
    return findings[:8]
